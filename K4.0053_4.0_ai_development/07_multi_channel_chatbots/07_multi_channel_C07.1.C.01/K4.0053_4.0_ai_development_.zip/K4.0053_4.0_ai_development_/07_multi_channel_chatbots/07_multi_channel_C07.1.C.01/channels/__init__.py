"""Channel adapters for different messaging platforms."""

from .whatsapp_parser import parse_whatsapp_webhook
from .mock_whatsapp import MockWhatsAppClient, LiveWhatsAppClient

__all__ = [
    "parse_whatsapp_webhook",
    "MockWhatsAppClient",
    "LiveWhatsAppClient",
]

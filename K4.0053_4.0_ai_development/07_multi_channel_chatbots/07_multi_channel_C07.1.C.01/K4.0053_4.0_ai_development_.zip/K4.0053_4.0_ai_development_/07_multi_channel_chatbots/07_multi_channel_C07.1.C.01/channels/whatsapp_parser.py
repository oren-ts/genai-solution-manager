"""
WhatsApp webhook payload parser.

Extracts user ID and message text from WhatsApp Cloud API webhook payloads.
Handles various message types and error cases gracefully.
"""

from typing import Optional, Dict, Any
from utils import logger


def parse_whatsapp_webhook(payload: Dict[str, Any]) -> Optional[tuple[str, str]]:
    """
    Parse WhatsApp webhook payload to extract user ID and message text.
    
    WhatsApp webhook structure (simplified):
    {
        "entry": [{
            "changes": [{
                "value": {
                    "messages": [{
                        "from": "1234567890",
                        "text": {"body": "Hello"},
                        "type": "text"
                    }]
                }
            }]
        }]
    }
    
    Args:
        payload: Webhook payload from WhatsApp
    
    Returns:
        Tuple of (user_id, message_text) or None if parsing fails
    """
    try:
        # Navigate the nested structure
        entry = payload.get("entry", [])
        if not entry:
            logger.warning("No 'entry' field in WhatsApp webhook")
            return None
        
        changes = entry[0].get("changes", [])
        if not changes:
            logger.warning("No 'changes' field in WhatsApp webhook")
            return None
        
        value = changes[0].get("value", {})
        messages = value.get("messages", [])
        
        if not messages:
            # This might be a status update, not a message
            logger.debug("No messages in webhook (possibly status update)")
            return None
        
        message = messages[0]
        
        # Extract user ID (phone number)
        user_id = message.get("from")
        if not user_id:
            logger.warning("No 'from' field in message")
            return None
        
        # Extract text based on message type
        message_type = message.get("type")
        
        if message_type == "text":
            text_obj = message.get("text", {})
            text = text_obj.get("body", "")
        else:
            # Handle non-text messages (image, video, etc.)
            logger.info(f"Received non-text message type: {message_type}")
            text = f"[Received {message_type} message - text messages only supported]"
        
        if not text:
            logger.warning("Empty message text")
            return None
        
        logger.debug(f"Parsed WhatsApp message: user_id={user_id}, text={text[:50]}...")
        return (user_id, text)
        
    except (KeyError, IndexError, TypeError) as e:
        logger.error(f"Failed to parse WhatsApp webhook: {e}", exc_info=True)
        return None
    except Exception as e:
        logger.error(f"Unexpected error parsing WhatsApp webhook: {e}", exc_info=True)
        return None

#!/usr/bin/env python3
"""
End-to-end test of complete chatbot functionality.

Demonstrates all three intents with real conversations:
- Opening hours (with day extraction)
- Product info (with product/category extraction)
- Order status (with multi-turn conversation and privacy)
"""

import sys
from pathlib import Path

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent))

from core import IncomingMessage, context_manager, process_message


def print_conversation(title: str):
    """Print conversation section header."""
    print("\n" + "=" * 80)
    print(f"  {title}")
    print("=" * 80 + "\n")


def chat(user_id: str, channel: str, text: str) -> str:
    """
    Simulate a chat interaction.
    
    Args:
        user_id: User identifier
        channel: Channel name
        text: User message
    
    Returns:
        Bot response text
    """
    # Create incoming message
    message = IncomingMessage(
        channel=channel,
        user_id=user_id,
        text=text
    )
    
    # Get session
    session = context_manager.get_session(user_id, channel)
    
    # Process message
    response = process_message(message, session)
    
    # Display conversation
    print(f"👤 User: {text}")
    print(f"🤖 Bot: {response.text}")
    if response.options:
        print(f"   Quick replies: {', '.join(response.options)}")
    print()
    
    return response.text


def main():
    """Run end-to-end chatbot demonstration."""
    print("\n" + "💬 " * 20)
    print("  COMPLETE CHATBOT END-TO-END DEMONSTRATION")
    print("💬 " * 20)
    
    # ========================================================================
    # Scenario 1: Opening Hours
    # ========================================================================
    print_conversation("Scenario 1: Opening Hours Query")
    
    chat("user_1", "webchat", "When are you open?")
    chat("user_1", "webchat", "What about Saturday?")
    chat("user_1", "webchat", "Are you open today?")
    
    # ========================================================================
    # Scenario 2: Product Information
    # ========================================================================
    print_conversation("Scenario 2: Product Information")
    
    chat("user_2", "whatsapp", "How much is a cappuccino?")
    chat("user_2", "whatsapp", "What about espresso?")
    chat("user_2", "whatsapp", "Show me all coffee options")
    chat("user_2", "whatsapp", "Do you have pastries?")
    
    # ========================================================================
    # Scenario 3: Order Status (Multi-turn with ID provided)
    # ========================================================================
    print_conversation("Scenario 3: Order Status - With ID")
    
    chat("1234567890", "whatsapp", "What's the status of order A123?")
    
    # ========================================================================
    # Scenario 4: Order Status (Multi-turn without ID)
    # ========================================================================
    print_conversation("Scenario 4: Order Status - Multi-turn Conversation")
    
    chat("user_4", "webchat", "Check my order status")
    chat("user_4", "webchat", "B456")  # User provides ID in follow-up
    
    # ========================================================================
    # Scenario 5: Privacy Check (Wrong Customer)
    # ========================================================================
    print_conversation("Scenario 5: Privacy Protection")
    
    print("User 0987654321 tries to check order A123 (belongs to 1234567890):")
    chat("0987654321", "whatsapp", "Track order A123")
    
    print("Same user checks their own order C789:")
    chat("0987654321", "whatsapp", "Check order C789")
    
    # ========================================================================
    # Scenario 6: Unknown Intents
    # ========================================================================
    print_conversation("Scenario 6: Unknown Intent Handling")
    
    chat("user_6", "webchat", "Hello!")
    chat("user_6", "webchat", "What is the meaning of life?")
    
    # ========================================================================
    # Scenario 7: Product Aliases
    # ========================================================================
    print_conversation("Scenario 7: Product Name Aliases")
    
    chat("user_7", "webchat", "How much for a cap?")  # Alias for cappuccino
    
    # ========================================================================
    # Scenario 8: Case Insensitivity
    # ========================================================================
    print_conversation("Scenario 8: Case Insensitivity")
    
    chat("1234567890", "whatsapp", "TRACK ORDER a123")  # Lowercase order ID
    
    # ========================================================================
    # Summary
    # ========================================================================
    print("\n" + "=" * 80)
    print("  ✅ END-TO-END DEMONSTRATION COMPLETE!")
    print("=" * 80)
    print("\n📊 What We Just Demonstrated:")
    print("  ✅ Intent detection (3 types)")
    print("  ✅ Entity extraction (order IDs, products, days)")
    print("  ✅ Data lookup from JSON")
    print("  ✅ Multi-turn conversations (order status without ID)")
    print("  ✅ Privacy enforcement (users can only see their orders)")
    print("  ✅ Case insensitivity (a123 → A123)")
    print("  ✅ Product aliases (cap → cappuccino)")
    print("  ✅ Day resolution (today, tomorrow)")
    print("  ✅ Unknown intent fallback")
    print("  ✅ Session management across messages")
    print("\n🎉 The chatbot is FULLY FUNCTIONAL!\n")


if __name__ == "__main__":
    main()

"""
Data access layer for business data.

Loads business_data.json and provides lookup methods for:
- Opening hours (by day)
- Products (by name, alias, or category)
- Orders (by ID with privacy checks)

All data is loaded once on import and cached in memory.
"""

import json
from pathlib import Path
from typing import Optional, Dict, List, Any
from datetime import datetime
from utils import logger


class DataLoader:
    """
    Load and query business data from JSON file.
    
    This class provides safe, validated access to opening hours,
    products, and order data with proper error handling.
    """
    
    def __init__(self, data_file: str = "data/business_data.json"):
        """
        Initialize data loader.
        
        Args:
            data_file: Path to JSON data file (relative to project root)
        """
        self.data_file = Path(__file__).parent.parent / data_file
        self.data: Dict[str, Any] = {}
        self._load_data()
    
    def _load_data(self) -> None:
        """Load and validate data from JSON file."""
        try:
            logger.info(f"Loading business data from {self.data_file}")
            
            if not self.data_file.exists():
                logger.error(f"Data file not found: {self.data_file}")
                self.data = self._get_empty_data()
                return
            
            with open(self.data_file, 'r', encoding='utf-8') as f:
                self.data = json.load(f)
            
            # Validate structure
            required_keys = ['opening_hours', 'products', 'orders']
            missing_keys = [key for key in required_keys if key not in self.data]
            
            if missing_keys:
                logger.warning(f"Missing keys in data file: {missing_keys}")
            
            # Log data summary
            logger.info(
                f"Loaded data: "
                f"{len(self.data.get('products', {}))} products, "
                f"{len(self.data.get('orders', {}))} orders"
            )
            
        except json.JSONDecodeError as e:
            logger.error(f"Invalid JSON in data file: {e}")
            self.data = self._get_empty_data()
        except Exception as e:
            logger.error(f"Failed to load data: {e}", exc_info=True)
            self.data = self._get_empty_data()
    
    def _get_empty_data(self) -> Dict[str, Any]:
        """Return empty data structure for graceful degradation."""
        return {
            'opening_hours': {},
            'products': {},
            'product_categories': {},
            'orders': {}
        }
    
    # ========== OPENING HOURS ==========
    
    def get_opening_hours(self, day: Optional[str] = None) -> Dict[str, str]:
        """
        Get opening hours for a specific day or all days.
        
        Args:
            day: Day of week (monday, tuesday, etc.) or special values:
                 - "today": Current day
                 - "tomorrow": Next day
                 - None: Return all days
        
        Returns:
            Dictionary with day(s) and hours
            Example: {"monday": "08:00-18:00", "tuesday": "08:00-18:00"}
        """
        hours = self.data.get('opening_hours', {})
        
        if not hours:
            logger.warning("No opening hours data available")
            return {}
        
        # If no day specified, return all
        if day is None:
            return hours
        
        # Handle "today" and "tomorrow"
        if day.lower() in ['today', 'tomorrow']:
            day = self._resolve_day(day.lower())
        
        # Normalize day name (case-insensitive)
        day = day.lower()
        
        # Return specific day
        if day in hours:
            return {day: hours[day]}
        
        logger.warning(f"No hours found for day: {day}")
        return {}
    
    def _resolve_day(self, special_day: str) -> str:
        """
        Resolve 'today' or 'tomorrow' to actual day name.
        
        Args:
            special_day: "today" or "tomorrow"
        
        Returns:
            Day name (e.g., "monday")
        """
        days = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday']
        today_index = datetime.now().weekday()  # 0=Monday, 6=Sunday
        
        if special_day == 'today':
            return days[today_index]
        elif special_day == 'tomorrow':
            return days[(today_index + 1) % 7]
        
        return special_day
    
    def format_opening_hours(self, hours: Dict[str, str]) -> str:
        """
        Format opening hours for display.
        
        Args:
            hours: Dictionary of day → hours
        
        Returns:
            Formatted string for display
        """
        if not hours:
            return "Opening hours information not available."
        
        # If single day
        if len(hours) == 1:
            day, time = list(hours.items())[0]
            day_cap = day.capitalize()
            if time.lower() == 'closed':
                return f"We're closed on {day_cap}."
            return f"On {day_cap}, we're open {time}."
        
        # Multiple days - format as list
        lines = ["Our opening hours:"]
        for day, time in hours.items():
            day_cap = day.capitalize()
            lines.append(f"• {day_cap}: {time}")
        
        return "\n".join(lines)
    
    # ========== PRODUCTS ==========
    
    def get_product(self, query: str) -> Optional[Dict[str, Any]]:
        """
        Find product by name or alias.
        
        Args:
            query: Product name or alias (case-insensitive)
        
        Returns:
            Product dict or None if not found
        """
        query_lower = query.lower().strip()
        products = self.data.get('products', {})
        
        # Try exact match on product key
        if query_lower in products:
            return products[query_lower]
        
        # Try alias matching
        for product_key, product_data in products.items():
            aliases = product_data.get('aliases', [])
            if query_lower in [alias.lower() for alias in aliases]:
                return product_data
        
        logger.debug(f"Product not found: {query}")
        return None
    
    def get_products_by_category(self, category: str) -> List[Dict[str, Any]]:
        """
        Get all products in a category.
        
        Args:
            category: Category name (e.g., "coffee", "tea")
        
        Returns:
            List of product dictionaries
        """
        category_lower = category.lower().strip()
        products = self.data.get('products', {})
        
        # Get product keys from category mapping
        categories = self.data.get('product_categories', {})
        product_keys = categories.get(category_lower, [])
        
        # If no category mapping, search by product.category field
        if not product_keys:
            product_keys = [
                key for key, data in products.items()
                if data.get('category', '').lower() == category_lower
            ]
        
        # Return full product data
        return [products[key] for key in product_keys if key in products]
    
    def format_product(self, product: Dict[str, Any]) -> str:
        """
        Format product for display.
        
        Args:
            product: Product dictionary
        
        Returns:
            Formatted string
        """
        name = product.get('name', 'Unknown')
        price = product.get('price', 0.0)
        description = product.get('description', '')
        
        result = f"**{name}** - ${price:.2f}"
        if description:
            result += f"\n{description}"
        
        return result
    
    def format_product_list(self, products: List[Dict[str, Any]]) -> str:
        """
        Format multiple products for display.
        
        Args:
            products: List of product dictionaries
        
        Returns:
            Formatted string with all products
        """
        if not products:
            return "No products found in this category."
        
        lines = []
        for product in products:
            name = product.get('name', 'Unknown')
            price = product.get('price', 0.0)
            lines.append(f"• {name} - ${price:.2f}")
        
        return "\n".join(lines)
    
    # ========== ORDERS ==========
    
    def get_order(
        self,
        order_id: str,
        customer_phone: Optional[str] = None,
        enforce_privacy: bool = True
    ) -> Optional[Dict[str, Any]]:
        """
        Find order by ID with optional privacy check.
        
        Args:
            order_id: Order identifier (case-insensitive)
            customer_phone: Customer's phone number for privacy check
            enforce_privacy: If True, only return order if customer_phone matches
        
        Returns:
            Order dict or None if not found/unauthorized
        """
        # Normalize order ID (case-insensitive, remove whitespace)
        order_id_normalized = order_id.strip().upper()
        
        orders = self.data.get('orders', {})
        
        # Find order (keys might be in different case)
        order = None
        for key, data in orders.items():
            if key.upper() == order_id_normalized:
                order = data
                break
        
        if not order:
            logger.debug(f"Order not found: {order_id_normalized}")
            return None
        
        # Privacy check
        if enforce_privacy and customer_phone:
            order_phone = order.get('customer_phone', '')
            
            # Normalize phone numbers (remove spaces, dashes, etc.)
            customer_clean = ''.join(filter(str.isdigit, customer_phone))
            order_clean = ''.join(filter(str.isdigit, order_phone))
            
            if customer_clean != order_clean:
                logger.warning(
                    f"Privacy check failed: Order {order_id_normalized} "
                    f"requested by {customer_phone} but belongs to {order_phone}"
                )
                return None
        
        return order
    
    def format_order(self, order: Dict[str, Any]) -> str:
        """
        Format order for display.
        
        Args:
            order: Order dictionary
        
        Returns:
            Formatted string with status and ETA
        """
        order_id = order.get('order_id', 'Unknown')
        status = order.get('status', 'Unknown')
        eta = order.get('eta')
        items = order.get('items', [])
        
        result = f"**Order {order_id}**\n"
        result += f"Status: {status}\n"
        
        if eta:
            result += f"Estimated delivery: {eta}\n"
        
        if items:
            result += f"Items: {', '.join(items)}"
        
        return result


# Global data loader instance
data_loader = DataLoader()

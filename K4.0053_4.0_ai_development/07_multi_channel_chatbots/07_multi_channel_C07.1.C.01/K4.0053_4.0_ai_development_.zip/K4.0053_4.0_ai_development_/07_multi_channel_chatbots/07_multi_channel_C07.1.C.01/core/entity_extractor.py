"""
Entity extraction using regex patterns and NLP techniques.

Extracts structured information from user messages:
- order_id: Order identifiers (e.g., A123, B456)
- product_name: Product names and aliases
- day: Day references (today, tomorrow, monday, etc.)
"""

import re
from typing import List
from core.models import Entity
from utils import logger


# Regex patterns for entity extraction
PATTERNS = {
    # Order ID: Letter followed by 3+ digits (e.g., A123, B456, C7890)
    "order_id": r'\b([A-Z]\d{3,})\b',
    
    # Day of week (full or abbreviated)
    "day": r'\b(monday|tuesday|wednesday|thursday|friday|saturday|sunday|mon|tue|wed|thu|fri|sat|sun|today|tomorrow)\b',
}

# Product names and aliases (from business data)
PRODUCT_NAMES = {
    "espresso": ["espresso", "shot"],
    "cappuccino": ["cappuccino", "cap", "capp"],
    "latte": ["latte", "cafe latte"],
    "americano": ["americano", "american coffee"],
    "croissant": ["croissant"],
    "muffin": ["muffin"],
    "green_tea": ["green tea", "green"],
    "black_tea": ["black tea", "black"],
    "herbal_tea": ["herbal tea", "herbal"],
}

# Product categories
PRODUCT_CATEGORIES = {
    "coffee": ["coffee", "coffees"],
    "tea": ["tea", "teas"],
    "pastries": ["pastry", "pastries", "pastry", "baked goods"],
}


def extract_entities(text: str, intent_name: str = None) -> List[Entity]:
    """
    Extract entities from user message.
    
    Extracts different entity types based on detected intent:
    - opening_hours: day references
    - product_info: product names, categories
    - order_status: order IDs
    
    Args:
        text: User message text
        intent_name: Detected intent (helps narrow entity types to look for)
    
    Returns:
        List of extracted entities
    """
    logger.debug(f"Extracting entities from: '{text}' (intent: {intent_name})")
    
    entities: List[Entity] = []
    text_lower = text.lower()
    
    # Extract based on intent
    if intent_name == "opening_hours":
        # Look for day references
        entities.extend(_extract_days(text_lower))
    
    elif intent_name == "product_info":
        # Look for product names and categories
        entities.extend(_extract_products(text_lower))
        entities.extend(_extract_categories(text_lower))
    
    elif intent_name == "order_status":
        # Look for order IDs (case-insensitive but preserve original)
        entities.extend(_extract_order_ids(text))
    
    else:
        # Unknown intent - try extracting all entity types
        entities.extend(_extract_order_ids(text))
        entities.extend(_extract_products(text_lower))
        entities.extend(_extract_days(text_lower))
    
    logger.debug(f"Extracted {len(entities)} entities: {[e.dict() for e in entities]}")
    
    return entities


def _extract_order_ids(text: str) -> List[Entity]:
    """
    Extract order IDs using regex pattern.
    
    Pattern: Letter followed by 3+ digits (e.g., A123, B456)
    Preserves original case for the letter.
    
    Args:
        text: User message (original case)
    
    Returns:
        List of order_id entities
    """
    entities = []
    
    # Make case-insensitive match
    pattern = PATTERNS["order_id"]
    matches = re.finditer(pattern, text.upper())
    
    for match in matches:
        order_id = match.group(1)
        entities.append(Entity(
            type="order_id",
            value=order_id,
            confidence=1.0  # Regex match is high confidence
        ))
    
    return entities


def _extract_days(text: str) -> List[Entity]:
    """
    Extract day references.
    
    Matches: today, tomorrow, monday-sunday (full or abbreviated)
    
    Args:
        text: User message (lowercase)
    
    Returns:
        List of day entities
    """
    entities = []
    
    pattern = PATTERNS["day"]
    matches = re.finditer(pattern, text)
    
    for match in matches:
        day = match.group(1)
        
        # Normalize abbreviated days
        day_normalized = _normalize_day(day)
        
        entities.append(Entity(
            type="day",
            value=day_normalized,
            confidence=1.0
        ))
    
    return entities


def _normalize_day(day: str) -> str:
    """
    Normalize day abbreviations to full names.
    
    Args:
        day: Day string (e.g., "mon", "monday", "today")
    
    Returns:
        Normalized day name
    """
    day_map = {
        "mon": "monday",
        "tue": "tuesday",
        "wed": "wednesday",
        "thu": "thursday",
        "fri": "friday",
        "sat": "saturday",
        "sun": "sunday",
    }
    
    return day_map.get(day, day)


def _extract_products(text: str) -> List[Entity]:
    """
    Extract product names using fuzzy matching.
    
    Checks for product names and their aliases.
    
    Args:
        text: User message (lowercase)
    
    Returns:
        List of product_name entities
    """
    entities = []
    seen = set()  # Avoid duplicates
    
    for product_key, aliases in PRODUCT_NAMES.items():
        for alias in aliases:
            # Check if alias appears in text as whole word
            pattern = r'\b' + re.escape(alias) + r'\b'
            if re.search(pattern, text):
                if product_key not in seen:
                    entities.append(Entity(
                        type="product_name",
                        value=product_key,
                        confidence=0.9  # Slightly lower for potential ambiguity
                    ))
                    seen.add(product_key)
    
    return entities


def _extract_categories(text: str) -> List[Entity]:
    """
    Extract product category references.
    
    Args:
        text: User message (lowercase)
    
    Returns:
        List of product_category entities
    """
    entities = []
    
    for category_key, aliases in PRODUCT_CATEGORIES.items():
        for alias in aliases:
            pattern = r'\b' + re.escape(alias) + r'\b'
            if re.search(pattern, text):
                entities.append(Entity(
                    type="product_category",
                    value=category_key,
                    confidence=0.8
                ))
                break  # Only add each category once
    
    return entities

"""
Session and context management for multi-turn conversations.

Manages user sessions in-memory with TTL-based expiry.
In production, this would be replaced with Redis or similar.
"""

from typing import Optional, Dict
from datetime import datetime, timedelta
from core.models import Session
from config import settings
from utils import logger


class ContextManager:
    """
    Manages user conversation sessions with automatic expiry.
    
    Sessions are stored in-memory and expire after SESSION_TTL_MINUTES
    of inactivity. This is suitable for prototypes; production should
    use Redis or similar for distributed session storage.
    """
    
    def __init__(self):
        self._sessions: Dict[str, Session] = {}
        self._ttl = timedelta(minutes=settings.session_ttl_minutes)
    
    def get_session(self, user_id: str, channel: str) -> Session:
        """
        Get or create a session for the user.
        
        Args:
            user_id: Unique user identifier
            channel: Channel name (whatsapp, webchat, etc.)
        
        Returns:
            Session object (existing or newly created)
        """
        # Create composite key (user might use multiple channels)
        session_key = f"{channel}:{user_id}"
        
        # Check if session exists and is valid
        if session_key in self._sessions:
            session = self._sessions[session_key]
            
            # Check if session has expired
            if datetime.utcnow() - session.last_activity > self._ttl:
                logger.info(f"Session expired for {session_key}, creating new session")
                del self._sessions[session_key]
            else:
                # Update activity timestamp
                session.update_activity()
                logger.debug(f"Retrieved existing session for {session_key}")
                return session
        
        # Create new session
        session = Session(user_id=user_id, channel=channel)
        self._sessions[session_key] = session
        logger.info(f"Created new session for {session_key}")
        return session
    
    def update_session(self, user_id: str, channel: str, **kwargs) -> None:
        """
        Update session fields.
        
        Args:
            user_id: User identifier
            channel: Channel name
            **kwargs: Fields to update (pending_intent, entities, etc.)
        """
        session_key = f"{channel}:{user_id}"
        
        if session_key in self._sessions:
            session = self._sessions[session_key]
            
            for key, value in kwargs.items():
                if hasattr(session, key):
                    setattr(session, key, value)
            
            session.update_activity()
            logger.debug(f"Updated session {session_key}: {kwargs}")
        else:
            logger.warning(f"Attempted to update non-existent session: {session_key}")
    
    def clear_session(self, user_id: str, channel: str) -> None:
        """
        Clear a user's session.
        
        Args:
            user_id: User identifier
            channel: Channel name
        """
        session_key = f"{channel}:{user_id}"
        
        if session_key in self._sessions:
            del self._sessions[session_key]
            logger.info(f"Cleared session for {session_key}")
    
    def cleanup_expired_sessions(self) -> int:
        """
        Remove all expired sessions.
        
        Returns:
            Number of sessions removed
        """
        now = datetime.utcnow()
        expired_keys = [
            key for key, session in self._sessions.items()
            if now - session.last_activity > self._ttl
        ]
        
        for key in expired_keys:
            del self._sessions[key]
        
        if expired_keys:
            logger.info(f"Cleaned up {len(expired_keys)} expired sessions")
        
        return len(expired_keys)
    
    def get_session_count(self) -> int:
        """Get count of active sessions."""
        return len(self._sessions)


# Global context manager instance
context_manager = ContextManager()

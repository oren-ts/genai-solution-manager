"""
Structured logging setup with format switching (pretty/json).

In development (LOG_FORMAT=pretty):
- Human-readable console output with colors
- Easy to scan during debugging

In production/CI (LOG_FORMAT=json):
- Structured JSON logs
- Machine-readable for log aggregation tools
"""

import logging
import sys
import json
from datetime import datetime
from typing import Any, Dict
from config import settings


class JSONFormatter(logging.Formatter):
    """Format log records as JSON for machine parsing."""
    
    def format(self, record: logging.LogRecord) -> str:
        log_data: Dict[str, Any] = {
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "level": record.levelname,
            "message": record.getMessage(),
            "module": record.module,
            "function": record.funcName,
            "line": record.lineno,
        }
        
        # Add exception info if present
        if record.exc_info:
            log_data["exception"] = self.formatException(record.exc_info)
        
        # Add extra fields from record
        if hasattr(record, "extra_fields"):
            log_data.update(record.extra_fields)
        
        return json.dumps(log_data)


class PrettyFormatter(logging.Formatter):
    """Human-readable colored console output for development."""
    
    # ANSI color codes
    COLORS = {
        "DEBUG": "\033[36m",      # Cyan
        "INFO": "\033[32m",       # Green
        "WARNING": "\033[33m",    # Yellow
        "ERROR": "\033[31m",      # Red
        "CRITICAL": "\033[35m",   # Magenta
    }
    RESET = "\033[0m"
    
    def format(self, record: logging.LogRecord) -> str:
        # Add color to level name
        level_color = self.COLORS.get(record.levelname, "")
        record.levelname = f"{level_color}{record.levelname}{self.RESET}"
        
        # Format: [TIME] LEVEL module.function:line - message
        timestamp = datetime.now().strftime("%H:%M:%S")
        location = f"{record.module}.{record.funcName}:{record.lineno}"
        
        message = f"[{timestamp}] {record.levelname:20} {location:30} - {record.getMessage()}"
        
        # Add exception if present
        if record.exc_info:
            message += "\n" + self.formatException(record.exc_info)
        
        return message


def setup_logger(name: str = "chatbot") -> logging.Logger:
    """
    Configure and return a logger instance.
    
    Args:
        name: Logger name (default: "chatbot")
    
    Returns:
        Configured logger instance
    """
    logger = logging.getLogger(name)
    logger.setLevel(logging.DEBUG)
    
    # Remove existing handlers to avoid duplicates
    logger.handlers.clear()
    
    # Create console handler
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(logging.DEBUG)
    
    # Choose formatter based on config
    if settings.log_format == "json":
        formatter = JSONFormatter()
    else:
        formatter = PrettyFormatter()
    
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)
    
    return logger


# Global logger instance
logger = setup_logger()

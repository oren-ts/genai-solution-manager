"""
Intent detection using keyword matching and pattern recognition.

Supports three main intents:
- opening_hours: Questions about when the business is open
- product_info: Questions about products, prices, menu
- order_status: Questions about order tracking and status

Uses weighted keyword matching with confidence scoring.
"""

from typing import List, Dict, Set
from core.models import Intent
from utils import logger


# Intent keyword definitions with weights
INTENT_KEYWORDS: Dict[str, Dict[str, float]] = {
    "opening_hours": {
        # High confidence keywords
        "open": 1.0,
        "hours": 1.0,
        "opening": 1.0,
        "close": 0.9,
        "closed": 0.9,
        "closing": 0.9,
        # Medium confidence keywords
        "when": 0.6,
        "time": 0.6,
        "schedule": 0.8,
        # Context words
        "today": 0.4,
        "tomorrow": 0.4,
        "monday": 0.3,
        "tuesday": 0.3,
        "wednesday": 0.3,
        "thursday": 0.3,
        "friday": 0.3,
        "saturday": 0.3,
        "sunday": 0.3,
    },
    "product_info": {
        # High confidence keywords
        "price": 1.0,
        "cost": 1.0,
        "menu": 1.0,
        "product": 0.9,
        "products": 0.9,
        # Medium confidence keywords
        "coffee": 0.7,
        "espresso": 0.8,
        "cappuccino": 0.8,
        "latte": 0.8,
        "americano": 0.8,
        "tea": 0.7,
        "croissant": 0.8,
        "muffin": 0.8,
        "pastry": 0.7,
        "pastries": 0.7,
        # Questions
        "much": 0.5,
        "sell": 0.6,
        "have": 0.4,
        "offer": 0.6,
    },
    "order_status": {
        # High confidence keywords
        "order": 1.0,
        "status": 0.9,
        "tracking": 1.0,
        "track": 0.9,
        # Medium confidence keywords
        "where": 0.6,
        "shipped": 0.8,
        "delivery": 0.8,
        "deliver": 0.7,
        "eta": 0.9,
        "arrive": 0.7,
        # Questions
        "check": 0.5,
        "find": 0.5,
        "my": 0.3,
    }
}


def detect_intent(text: str, conversation_history: List[str] = None) -> Intent:
    """
    Detect user intent from message text using keyword matching.
    
    Algorithm:
    1. Normalize text (lowercase, tokenize)
    2. Calculate weighted score for each intent
    3. Return intent with highest score (if above threshold)
    4. Consider conversation context for disambiguation
    
    Args:
        text: User message text
        conversation_history: Previous messages for context (optional)
    
    Returns:
        Intent object with name and confidence score
    """
    logger.debug(f"Detecting intent for: '{text}'")
    
    # Normalize text
    text_lower = text.lower().strip()
    
    # Handle empty or very short messages
    if len(text_lower) < 2:
        logger.debug("Message too short for intent detection")
        return Intent(name="unknown", confidence=0.0)
    
    # Tokenize (simple word splitting)
    tokens = _tokenize(text_lower)
    
    if not tokens:
        logger.debug("No valid tokens found")
        return Intent(name="unknown", confidence=0.0)
    
    # Calculate scores for each intent
    scores: Dict[str, float] = {}
    
    for intent_name, keywords in INTENT_KEYWORDS.items():
        score = _calculate_intent_score(tokens, keywords)
        scores[intent_name] = score
    
    # Find best intent
    best_intent = max(scores.items(), key=lambda x: x[1])
    intent_name, confidence = best_intent
    
    # Confidence threshold: require at least 0.3 to avoid false positives
    CONFIDENCE_THRESHOLD = 0.3
    
    if confidence < CONFIDENCE_THRESHOLD:
        logger.debug(f"All scores below threshold: {scores}")
        return Intent(name="unknown", confidence=confidence)
    
    logger.debug(f"Detected intent: {intent_name} (confidence: {confidence:.2f}, scores: {scores})")
    
    return Intent(name=intent_name, confidence=confidence)


def _tokenize(text: str) -> List[str]:
    """
    Tokenize text into words.
    
    Removes punctuation and splits on whitespace.
    
    Args:
        text: Input text (already lowercase)
    
    Returns:
        List of tokens
    """
    # Remove common punctuation
    for char in '.,!?;:()[]{}"\'/\\':
        text = text.replace(char, ' ')
    
    # Split on whitespace and filter empty strings
    tokens = [token.strip() for token in text.split() if token.strip()]
    
    return tokens


def _calculate_intent_score(tokens: List[str], keywords: Dict[str, float]) -> float:
    """
    Calculate weighted score for an intent.
    
    Args:
        tokens: List of words from user message
        keywords: Dictionary of keyword → weight
    
    Returns:
        Normalized score between 0 and 1
    """
    total_weight = 0.0
    max_possible_weight = 0.0
    
    # Check each token against keywords
    for token in tokens:
        if token in keywords:
            weight = keywords[token]
            total_weight += weight
            max_possible_weight += 1.0  # Normalize by token count
        else:
            max_possible_weight += 0.1  # Small penalty for unmatched tokens
    
    # Avoid division by zero
    if max_possible_weight == 0:
        return 0.0
    
    # Normalize to 0-1 range
    score = min(1.0, total_weight / max_possible_weight)
    
    return score

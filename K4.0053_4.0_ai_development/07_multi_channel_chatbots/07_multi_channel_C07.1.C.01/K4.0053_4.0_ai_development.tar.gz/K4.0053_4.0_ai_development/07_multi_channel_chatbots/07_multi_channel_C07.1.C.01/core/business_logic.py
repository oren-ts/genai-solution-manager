"""
Core business logic for chatbot responses.

Coordinates intent detection, entity extraction, data lookup,
and response generation to provide intelligent, context-aware replies.
"""

from core.models import IncomingMessage, OutgoingMessage, Session
from core.intent_detector import detect_intent
from core.entity_extractor import extract_entities
from core.data_loader import data_loader
from utils import logger


def process_message(message: IncomingMessage, session: Session) -> OutgoingMessage:
    """
    Process incoming message and generate response.
    
    This is the main entry point for business logic. It:
    1. Detects user intent
    2. Extracts entities
    3. Looks up data (opening hours, products, orders)
    4. Generates appropriate response
    5. Updates session context
    
    Args:
        message: Incoming message from user
        session: User's conversation session
    
    Returns:
        Outgoing message with response text and optional quick replies
    """
    logger.info(f"Processing message from {message.user_id} on {message.channel}: {message.text}")
    
    # Add message to conversation history
    session.add_to_history(f"User: {message.text}")
    
    # Check if we're waiting for more info (multi-turn context)
    if session.pending_intent:
        response = _handle_pending_intent(message, session)
    else:
        # New query - detect intent and process
        response = _handle_new_query(message, session)
    
    # Add response to history
    session.add_to_history(f"Bot: {response.text}")
    
    return response


def _handle_new_query(message: IncomingMessage, session: Session) -> OutgoingMessage:
    """
    Handle a new user query (no pending context).
    
    Args:
        message: Incoming message
        session: User session
    
    Returns:
        Response message
    """
    # Detect intent
    intent = detect_intent(message.text, session.conversation_history)
    logger.debug(f"Detected intent: {intent.name} (confidence: {intent.confidence})")
    
    # Extract entities
    entities = extract_entities(message.text, intent.name)
    logger.debug(f"Extracted entities: {[e.dict() for e in entities]}")
    
    # Route to appropriate handler
    if intent.name == "opening_hours":
        return _handle_opening_hours(entities)
    
    elif intent.name == "product_info":
        return _handle_product_info(entities)
    
    elif intent.name == "order_status":
        return _handle_order_status(entities, message.user_id, session)
    
    else:
        # Unknown intent - provide helpful fallback
        return _generate_fallback_response(message.text)


def _handle_pending_intent(message: IncomingMessage, session: Session) -> OutgoingMessage:
    """
    Handle response when we're waiting for more information.
    
    For example, if user said "Check my order" without providing ID,
    we asked for ID and are now processing their response.
    
    Args:
        message: Incoming message
        session: User session with pending_intent set
    
    Returns:
        Response message
    """
    pending = session.pending_intent
    logger.info(f"Handling pending intent: {pending}")
    
    if pending == "order_status_need_id":
        # User should be providing order ID
        entities = extract_entities(message.text, "order_status")
        order_ids = [e for e in entities if e.type == "order_id"]
        
        if order_ids:
            # Got the ID - process it
            session.pending_intent = None  # Clear pending state
            return _handle_order_status(order_ids, message.user_id, session)
        else:
            # Still no ID - ask again with example
            return OutgoingMessage(
                text="I still need your order ID. It should look like A123 or B456. What's your order number?",
                options=None
            )
    
    # Unknown pending intent - clear and fallback
    session.pending_intent = None
    return _generate_fallback_response(message.text)


# ============================================================================
# INTENT HANDLERS
# ============================================================================

def _handle_opening_hours(entities: list) -> OutgoingMessage:
    """
    Handle opening hours query.
    
    Args:
        entities: Extracted entities (may include day)
    
    Returns:
        Response with opening hours
    """
    # Check if specific day was mentioned
    day_entities = [e for e in entities if e.type == "day"]
    
    if day_entities:
        # User asked about specific day(s)
        day = day_entities[0].value  # Take first day mentioned
        hours = data_loader.get_opening_hours(day)
    else:
        # No specific day - show all hours
        hours = data_loader.get_opening_hours()
    
    response_text = data_loader.format_opening_hours(hours)
    
    return OutgoingMessage(
        text=response_text,
        options=None  # No quick replies needed
    )


def _handle_product_info(entities: list) -> OutgoingMessage:
    """
    Handle product information query.
    
    Args:
        entities: Extracted entities (may include product_name or product_category)
    
    Returns:
        Response with product information
    """
    # Check for specific product
    product_entities = [e for e in entities if e.type == "product_name"]
    category_entities = [e for e in entities if e.type == "product_category"]
    
    if product_entities:
        # User asked about specific product
        product_name = product_entities[0].value
        product = data_loader.get_product(product_name)
        
        if product:
            response_text = data_loader.format_product(product)
        else:
            response_text = (
                f"I couldn't find information about '{product_name}'. "
                f"Would you like to see our full menu?"
            )
    
    elif category_entities:
        # User asked about category (e.g., "coffee")
        category = category_entities[0].value
        products = data_loader.get_products_by_category(category)
        
        if products:
            response_text = f"Here are our {category} options:\n\n"
            response_text += data_loader.format_product_list(products)
        else:
            response_text = f"We don't have any {category} products right now."
    
    else:
        # General product question - show all products
        coffee = data_loader.get_products_by_category("coffee")
        pastries = data_loader.get_products_by_category("pastries")
        
        response_text = "Here's our menu:\n\n**Coffee:**\n"
        response_text += data_loader.format_product_list(coffee)
        response_text += "\n\n**Pastries:**\n"
        response_text += data_loader.format_product_list(pastries)
    
    return OutgoingMessage(
        text=response_text,
        options=["Opening hours", "Order status"]  # Helpful navigation
    )


def _handle_order_status(entities: list, user_id: str, session: Session) -> OutgoingMessage:
    """
    Handle order status query.
    
    Args:
        entities: Extracted entities (may include order_id)
        user_id: User identifier (phone number for privacy check)
        session: User session (for multi-turn context)
    
    Returns:
        Response with order status or request for more info
    """
    # Check if order ID was provided
    order_id_entities = [e for e in entities if e.type == "order_id"]
    
    if not order_id_entities:
        # No order ID - ask for it (multi-turn conversation)
        session.pending_intent = "order_status_need_id"
        return OutgoingMessage(
            text="I'd be happy to check your order status! What's your order ID? (It should look like A123 or B456)",
            options=None
        )
    
    # Got order ID - look it up with privacy check
    order_id = order_id_entities[0].value
    order = data_loader.get_order(order_id, customer_phone=user_id, enforce_privacy=True)
    
    if order:
        # Found order and privacy check passed
        response_text = data_loader.format_order(order)
    else:
        # Order not found OR privacy check failed
        response_text = (
            f"I couldn't find order {order_id} in our system, or it doesn't belong to this account. "
            f"Please double-check the order ID.\n\n"
            f"If you need help, please contact our support team."
        )
    
    return OutgoingMessage(
        text=response_text,
        options=["Opening hours", "Product info"]  # Helpful navigation
    )


# ============================================================================
# FALLBACK HANDLER
# ============================================================================

def _generate_fallback_response(text: str) -> OutgoingMessage:
    """
    Generate a helpful fallback response when intent is unclear.
    
    Args:
        text: User's message
    
    Returns:
        Helpful fallback message with options
    """
    # Check for empty/emoji-only messages
    if not text.strip() or not any(c.isalnum() for c in text):
        return OutgoingMessage(
            text=(
                "Hello! I'm here to help. I can assist with:\n"
                "• Opening hours\n"
                "• Product information\n"
                "• Order status\n\n"
                "What would you like to know?"
            ),
            options=["Opening hours", "Product info", "Order status"]
        )
    
    # Generic fallback with guided options
    return OutgoingMessage(
        text=(
            "I'm not quite sure what you're asking about. I can help you with:\n\n"
            "• **Opening hours** - Ask \"When are you open?\"\n"
            "• **Product info** - Ask \"What products do you have?\"\n"
            "• **Order status** - Ask \"Check my order status\"\n\n"
            "What would you like to know?"
        ),
        options=["Opening hours", "Product info", "Order status"]
    )

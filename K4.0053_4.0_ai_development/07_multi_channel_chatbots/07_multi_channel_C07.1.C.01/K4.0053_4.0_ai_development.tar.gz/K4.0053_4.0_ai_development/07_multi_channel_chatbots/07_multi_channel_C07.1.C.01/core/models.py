"""
Data models for the chatbot using Pydantic for validation.

These models ensure type safety and provide automatic validation
for incoming requests and internal data structures.
"""

from pydantic import BaseModel, Field
from typing import Optional, Dict, Any, Literal
from datetime import datetime


class IncomingMessage(BaseModel):
    """
    Normalized incoming message from any channel.
    
    The translation layer converts channel-specific formats
    into this common structure for business logic processing.
    """
    channel: Literal["whatsapp", "webchat", "messenger"]
    user_id: str = Field(..., description="Unique user identifier (phone number or session ID)")
    text: str = Field(..., description="Message text content")
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    raw_payload: Optional[Dict[str, Any]] = Field(default=None, description="Original channel payload for debugging")


class OutgoingMessage(BaseModel):
    """
    Normalized outgoing message to any channel.
    
    Business logic generates this format, and the channel adapter
    converts it to channel-specific API calls.
    """
    text: str = Field(..., description="Response text to send")
    options: Optional[list[str]] = Field(default=None, description="Quick reply options (if supported by channel)")
    metadata: Optional[Dict[str, Any]] = Field(default=None, description="Channel-specific metadata")


class Session(BaseModel):
    """
    User conversation session with context tracking.
    
    Stores multi-turn conversation state for handling
    flows that require multiple exchanges (e.g., order status).
    """
    user_id: str
    channel: str
    created_at: datetime = Field(default_factory=datetime.utcnow)
    last_activity: datetime = Field(default_factory=datetime.utcnow)
    
    # Context fields
    pending_intent: Optional[str] = Field(default=None, description="Intent waiting for more info (e.g., 'order_status')")
    conversation_history: list[str] = Field(default_factory=list, description="Recent messages for context")
    entities: Dict[str, Any] = Field(default_factory=dict, description="Extracted entities from conversation")
    
    def update_activity(self) -> None:
        """Update last activity timestamp."""
        self.last_activity = datetime.utcnow()
    
    def add_to_history(self, message: str, max_history: int = 10) -> None:
        """
        Add message to conversation history.
        
        Args:
            message: Message to add
            max_history: Maximum number of messages to retain
        """
        self.conversation_history.append(message)
        if len(self.conversation_history) > max_history:
            self.conversation_history = self.conversation_history[-max_history:]


class Intent(BaseModel):
    """Detected user intent with confidence score."""
    name: str = Field(..., description="Intent name (e.g., 'opening_hours', 'product_info', 'order_status')")
    confidence: float = Field(..., ge=0.0, le=1.0, description="Confidence score between 0 and 1")


class Entity(BaseModel):
    """Extracted entity from user message."""
    type: str = Field(..., description="Entity type (e.g., 'order_id', 'product_name', 'day')")
    value: str = Field(..., description="Extracted value")
    confidence: float = Field(default=1.0, ge=0.0, le=1.0)


# WebChat API models
class WebChatRequest(BaseModel):
    """Request model for web chat endpoint."""
    user_id: str = Field(..., description="Session ID or user identifier")
    text: str = Field(..., min_length=1, description="Message text")


class WebChatResponse(BaseModel):
    """Response model for web chat endpoint."""
    reply_text: str
    options: Optional[list[str]] = None
    timestamp: datetime = Field(default_factory=datetime.utcnow)

"""
Configuration management for the multi-channel chatbot.

Supports two modes:
- mock: Runs without WhatsApp credentials, logs messages to console
- live: Connects to real WhatsApp Business API

Uses pydantic-settings for type-safe configuration from environment variables.
"""

from pydantic_settings import BaseSettings, SettingsConfigDict
from typing import Literal


class Settings(BaseSettings):
    """Application settings loaded from environment variables."""
    
    # Application mode
    mode: Literal["mock", "live"] = "mock"
    
    # Logging configuration
    log_format: Literal["pretty", "json"] = "pretty"
    
    # Session management
    session_ttl_minutes: int = 30
    
    # WhatsApp Business API credentials (optional in mock mode)
    whatsapp_verify_token: str = "default_verify_token"
    whatsapp_access_token: str = ""
    whatsapp_phone_number_id: str = ""
    whatsapp_business_account_id: str = ""
    
    # Optional: Webhook signature validation
    whatsapp_app_secret: str = ""
    validate_webhook_signature: bool = False
    
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore"
    )
    
    def validate_live_mode(self) -> None:
        """
        Validate that required credentials are present in live mode.
        
        Raises:
            ValueError: If live mode is enabled but credentials are missing
        """
        if self.mode == "live":
            missing = []
            if not self.whatsapp_access_token:
                missing.append("WHATSAPP_ACCESS_TOKEN")
            if not self.whatsapp_phone_number_id:
                missing.append("WHATSAPP_PHONE_NUMBER_ID")
            
            if missing:
                raise ValueError(
                    f"Live mode requires these environment variables: {', '.join(missing)}\n"
                    f"Set MODE=mock to run without credentials."
                )


# Global settings instance
settings = Settings()

# Validate configuration on import
if settings.mode == "live":
    settings.validate_live_mode()

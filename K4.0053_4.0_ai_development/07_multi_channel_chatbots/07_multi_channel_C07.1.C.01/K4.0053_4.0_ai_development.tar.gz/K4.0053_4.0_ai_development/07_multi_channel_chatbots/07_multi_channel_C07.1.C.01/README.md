# Multi-Channel Chatbot

A portfolio-grade customer support chatbot with WhatsApp Business API and Web Chat integration. Built with clean architecture, comprehensive error handling, and full testability without requiring live API credentials.

## 🎯 Features

- **Multi-Channel Support**: WhatsApp Business API and Web Chat
- **Mock Mode**: Run locally without API credentials
- **Smart Fallbacks**: Handles unknown intents gracefully
- **Context Management**: Multi-turn conversations with session state
- **Structured Logging**: Pretty console or JSON format
- **Type Safety**: Full Pydantic validation
- **Production-Ready**: Error handling, validation, and best practices

## 📋 Current Status

**✅ Phase 1 Complete: Walking Skeleton**
- [x] Project structure
- [x] FastAPI server with all endpoints
- [x] WhatsApp webhook verification (GET)
- [x] WhatsApp message receiver (POST)
- [x] Web chat endpoint
- [x] Mock WhatsApp client
- [x] Session management with TTL
- [x] Structured logging
- [x] Configuration management

**🚧 TODO: Full Logic Implementation**
- [ ] Intent detection (keyword matching + patterns)
- [ ] Entity extraction (order IDs, product names, dates)
- [ ] Data layer (load and query business_data.json)
- [ ] Response generation based on intents
- [ ] Multi-turn context for order status
- [ ] Unit and integration tests

## 🏗️ Architecture

```
┌─────────────┐         ┌─────────────┐
│  WhatsApp   │         │  Web Chat   │
│   Webhook   │         │   Client    │
└──────┬──────┘         └──────┬──────┘
       │                       │
       └───────┬───────────────┘
               │
        ┌──────▼──────┐
        │  FastAPI    │
        │  Endpoints  │
        └──────┬──────┘
               │
        ┌──────▼─────────────────────┐
        │  Translation Layer         │
        │  (Channel-specific parsing)│
        └──────┬─────────────────────┘
               │
        ┌──────▼──────────────────────┐
        │  Business Logic             │
        │  • Intent Detection         │
        │  • Entity Extraction        │
        │  • Data Lookup              │
        │  • Response Generation      │
        └──────┬──────────────────────┘
               │
        ┌──────▼──────────────────────┐
        │  Data Layer                 │
        │  (business_data.json)       │
        └─────────────────────────────┘
```

## 🚀 Quick Start

### Prerequisites

- Python 3.9+
- pip or pipenv

### Installation

1. **Clone and navigate:**
```bash
cd multichannel-chatbot
```

2. **Create virtual environment:**
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

3. **Install dependencies:**
```bash
pip install -r requirements.txt
```

4. **Configure environment:**
```bash
# .env file already created with MODE=mock
# No changes needed for local testing!
```

### Running the Server

```bash
uvicorn app:app --reload
```

The server will start at `http://localhost:8000`

**Auto-generated API docs:** http://localhost:8000/docs

## 🧪 Testing the Chatbot

### 1. Health Check

```bash
curl http://localhost:8000/health
```

Expected response:
```json
{
  "status": "healthy",
  "mode": "mock",
  "active_sessions": 0
}
```

### 2. Web Chat (Simple)

```bash
curl -X POST http://localhost:8000/webchat/message \
  -H "Content-Type: application/json" \
  -d '{
    "user_id": "web_user_123",
    "text": "Hello"
  }'
```

Expected response:
```json
{
  "reply_text": "I received your message: \"Hello\"\n\nI can help you with:...",
  "options": ["Opening hours", "Product info", "Order status"],
  "timestamp": "2024-02-14T10:30:00.000Z"
}
```

### 3. WhatsApp Webhook (Using Fixture)

**Verify webhook:**
```bash
curl "http://localhost:8000/webhook/whatsapp?hub.mode=subscribe&hub.verify_token=dev_verify_token_12345&hub.challenge=test123"
```

Expected: Returns `test123`

**Send test message:**
```bash
curl -X POST http://localhost:8000/webhook/whatsapp \
  -H "Content-Type: application/json" \
  -d @fixtures/whatsapp_opening_hours.json
```

Check the **console logs** to see the mock WhatsApp response!

### 4. Test All Fixtures

```bash
# Opening hours query
curl -X POST http://localhost:8000/webhook/whatsapp \
  -H "Content-Type: application/json" \
  -d @fixtures/whatsapp_opening_hours.json

# Order status query
curl -X POST http://localhost:8000/webhook/whatsapp \
  -H "Content-Type: application/json" \
  -d @fixtures/whatsapp_order_status.json

# Unknown intent
curl -X POST http://localhost:8000/webhook/whatsapp \
  -H "Content-Type: application/json" \
  -d @fixtures/whatsapp_unknown.json
```

## 📁 Project Structure

```
multichannel-chatbot/
├── app.py                      # FastAPI application
├── config.py                   # Settings with MODE switching
├── requirements.txt            # Dependencies
├── .env                        # Environment variables
├── .env.example               # Template
├── .gitignore                 # Git ignore rules
│
├── data/
│   └── business_data.json     # Customer data (hours, products, orders)
│
├── core/                      # Business logic
│   ├── models.py              # Pydantic models
│   ├── intent_detector.py     # Intent detection (TODO)
│   ├── entity_extractor.py    # Entity extraction (TODO)
│   ├── context_manager.py     # Session management
│   └── business_logic.py      # Main processing (stub)
│
├── channels/                  # Platform adapters
│   ├── whatsapp_parser.py     # Parse WhatsApp webhooks
│   └── mock_whatsapp.py       # Mock sender for testing
│
├── utils/
│   └── logger.py              # Structured logging
│
└── fixtures/                  # Test webhook payloads
    ├── whatsapp_opening_hours.json
    ├── whatsapp_order_status.json
    └── whatsapp_unknown.json
```

## ⚙️ Configuration

### Environment Variables

| Variable | Description | Required | Default |
|----------|-------------|----------|---------|
| `MODE` | `mock` or `live` | No | `mock` |
| `LOG_FORMAT` | `pretty` or `json` | No | `pretty` |
| `SESSION_TTL_MINUTES` | Session expiry time | No | `30` |
| `WHATSAPP_VERIFY_TOKEN` | Webhook verification | Only in `live` | - |
| `WHATSAPP_ACCESS_TOKEN` | API access token | Only in `live` | - |
| `WHATSAPP_PHONE_NUMBER_ID` | Phone number ID | Only in `live` | - |

### Switching to Live Mode

1. Get WhatsApp Business API credentials from [Meta for Developers](https://developers.facebook.com)
2. Update `.env`:
```
MODE=live
WHATSAPP_ACCESS_TOKEN=your_token_here
WHATSAPP_PHONE_NUMBER_ID=your_id_here
```
3. Deploy to a server with HTTPS (required by WhatsApp)
4. Register your webhook URL with Meta

## 🎯 Next Steps (Implementation TODO)

1. **Data Layer** (Phase 3.1)
   - Load and validate `business_data.json`
   - Implement lookup methods

2. **Intent Detection** (Phase 3.2)
   - Keyword matching for 3 intents
   - Pattern extraction (order IDs, etc.)

3. **Response Generation** (Phase 3.3)
   - Format responses based on intent
   - Handle edge cases

4. **Multi-turn Context** (Phase 3.4)
   - Order status flow with missing ID
   - Conversation state tracking

5. **Testing** (Phase 3.5)
   - Unit tests for core logic
   - Integration tests with fixtures

## 🔧 Development

### Code Quality

```bash
# Format code
black .

# Lint
flake8 .

# Type checking
mypy .
```

### Running Tests (when implemented)

```bash
pytest
```

## 📝 API Documentation

Once the server is running, visit:
- **Interactive docs:** http://localhost:8000/docs
- **ReDoc:** http://localhost:8000/redoc

## 🤝 Contributing

This is a portfolio project. See implementation TODOs in the code.

## 📄 License

MIT License - See LICENSE file

---

**Built with:** FastAPI, Pydantic, Python 3.9+
**Architecture:** Clean 3-layer design (Channels → Business Logic → Data)
**Philosophy:** Testable, maintainable, production-ready code

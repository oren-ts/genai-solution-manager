#!/usr/bin/env python3
"""
Test script for data layer functionality.

Tests loading, querying, and formatting of business data.
"""

import sys
from pathlib import Path

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent))

from core.data_loader import data_loader


def print_section(title):
    """Print formatted section header."""
    print("\n" + "=" * 80)
    print(f"  {title}")
    print("=" * 80 + "\n")


def test_opening_hours():
    """Test opening hours lookup."""
    print_section("1. Opening Hours Tests")
    
    # Test all days
    print("📅 All opening hours:")
    all_hours = data_loader.get_opening_hours()
    print(data_loader.format_opening_hours(all_hours))
    
    # Test specific day
    print("\n📅 Monday hours:")
    monday = data_loader.get_opening_hours('monday')
    print(data_loader.format_opening_hours(monday))
    
    # Test "today"
    print("\n📅 Today's hours:")
    today = data_loader.get_opening_hours('today')
    print(data_loader.format_opening_hours(today))
    
    # Test case insensitivity
    print("\n📅 SUNDAY hours (uppercase):")
    sunday = data_loader.get_opening_hours('SUNDAY')
    print(data_loader.format_opening_hours(sunday))
    
    print("\n✅ Opening hours tests passed!")


def test_products():
    """Test product lookup."""
    print_section("2. Product Tests")
    
    # Test exact match
    print("☕ Find 'cappuccino' (exact match):")
    product = data_loader.get_product('cappuccino')
    if product:
        print(data_loader.format_product(product))
    else:
        print("❌ Not found")
    
    # Test alias
    print("\n☕ Find 'cap' (alias):")
    product = data_loader.get_product('cap')
    if product:
        print(data_loader.format_product(product))
    else:
        print("❌ Not found")
    
    # Test case insensitivity
    print("\n☕ Find 'ESPRESSO' (uppercase):")
    product = data_loader.get_product('ESPRESSO')
    if product:
        print(data_loader.format_product(product))
    else:
        print("❌ Not found")
    
    # Test category
    print("\n☕ All coffee products:")
    coffee_products = data_loader.get_products_by_category('coffee')
    print(data_loader.format_product_list(coffee_products))
    
    # Test not found
    print("\n☕ Find 'unicorn_drink' (should not exist):")
    product = data_loader.get_product('unicorn_drink')
    if product:
        print("❌ UNEXPECTED: Found product")
    else:
        print("✅ Correctly returned None for non-existent product")
    
    print("\n✅ Product tests passed!")


def test_orders():
    """Test order lookup with privacy."""
    print_section("3. Order Tests")
    
    # Test successful order lookup
    print("📦 Order A123 for customer 1234567890:")
    order = data_loader.get_order('A123', customer_phone='1234567890')
    if order:
        print(data_loader.format_order(order))
    else:
        print("❌ Not found")
    
    # Test case insensitivity
    print("\n📦 Order a123 (lowercase):")
    order = data_loader.get_order('a123', customer_phone='1234567890')
    if order:
        print("✅ Found (case-insensitive working)")
        print(data_loader.format_order(order))
    else:
        print("❌ Not found")
    
    # Test privacy violation
    print("\n📦 Order A123 for WRONG customer (0987654321):")
    order = data_loader.get_order('A123', customer_phone='0987654321', enforce_privacy=True)
    if order:
        print("❌ PRIVACY VIOLATION: Returned order for wrong customer!")
    else:
        print("✅ Privacy check working - order blocked")
    
    # Test without privacy check
    print("\n📦 Order A123 WITHOUT privacy enforcement:")
    order = data_loader.get_order('A123', enforce_privacy=False)
    if order:
        print("✅ Found (privacy disabled)")
        print(data_loader.format_order(order))
    else:
        print("❌ Not found")
    
    # Test order not found
    print("\n📦 Order Z999 (should not exist):")
    order = data_loader.get_order('Z999', customer_phone='1234567890')
    if order:
        print("❌ UNEXPECTED: Found non-existent order")
    else:
        print("✅ Correctly returned None for non-existent order")
    
    # Test different customer's order
    print("\n📦 Order C789 for correct customer (0987654321):")
    order = data_loader.get_order('C789', customer_phone='0987654321')
    if order:
        print(data_loader.format_order(order))
    else:
        print("❌ Not found")
    
    print("\n✅ Order tests passed!")


def test_edge_cases():
    """Test edge cases and error handling."""
    print_section("4. Edge Cases")
    
    # Empty strings
    print("🔍 Empty product query:")
    product = data_loader.get_product('')
    print(f"Result: {product}")
    
    # Whitespace
    print("\n🔍 Product query with whitespace '  espresso  ':")
    product = data_loader.get_product('  espresso  ')
    if product:
        print(f"✅ Handled whitespace: {product.get('name')}")
    else:
        print("❌ Failed to handle whitespace")
    
    # Special characters
    print("\n🔍 Product query with special chars 'café':")
    product = data_loader.get_product('café')
    print(f"Result: {product}")
    
    print("\n✅ Edge case tests completed!")


def main():
    """Run all data layer tests."""
    print("\n" + "📊 " * 20)
    print("  DATA LAYER TEST SUITE")
    print("📊 " * 20)
    
    try:
        test_opening_hours()
        test_products()
        test_orders()
        test_edge_cases()
        
        print("\n" + "=" * 80)
        print("  ✅ ALL DATA LAYER TESTS PASSED!")
        print("=" * 80)
        print("\n📝 Data layer is working correctly!")
        print("   Next: Implement intent detection and entity extraction\n")
        
    except Exception as e:
        print(f"\n❌ TEST FAILED: {e}")
        import traceback
        traceback.print_exc()
        return 1
    
    return 0


if __name__ == "__main__":
    sys.exit(main())

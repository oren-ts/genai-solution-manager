"""
Mock WhatsApp client for local testing without API credentials.

Logs outgoing messages to console instead of sending to WhatsApp API.
This allows development and testing without needing a verified
WhatsApp Business account.
"""

from typing import Optional
from utils import logger


class MockWhatsAppClient:
    """
    Mock WhatsApp sender that logs messages instead of sending them.
    
    Used in MODE=mock to enable local development without credentials.
    """
    
    def __init__(self):
        logger.info("Initialized MockWhatsAppClient (messages will be logged, not sent)")
    
    def send_message(
        self,
        to: str,
        text: str,
        buttons: Optional[list[str]] = None
    ) -> dict:
        """
        Mock send message - logs to console instead of calling API.
        
        Args:
            to: Recipient phone number
            text: Message text
            buttons: Optional quick reply buttons (WhatsApp supports these)
        
        Returns:
            Mock success response
        """
        logger.info("=" * 80)
        logger.info(f"📤 MOCK WHATSAPP MESSAGE")
        logger.info(f"To: {to}")
        logger.info(f"Text: {text}")
        
        if buttons:
            logger.info(f"Buttons: {buttons}")
        
        logger.info("=" * 80)
        
        # Return mock success response matching WhatsApp API format
        return {
            "messaging_product": "whatsapp",
            "contacts": [{"input": to, "wa_id": to}],
            "messages": [{"id": f"mock_msg_{hash(text)}"}]
        }


# For future implementation
class LiveWhatsAppClient:
    """
    Real WhatsApp client that calls the Cloud API.
    
    TODO: Implement when MODE=live is needed.
    """
    
    def __init__(self, access_token: str, phone_number_id: str):
        self.access_token = access_token
        self.phone_number_id = phone_number_id
        self.api_url = f"https://graph.facebook.com/v18.0/{phone_number_id}/messages"
        logger.info("Initialized LiveWhatsAppClient")
    
    def send_message(
        self,
        to: str,
        text: str,
        buttons: Optional[list[str]] = None
    ) -> dict:
        """
        Send message via WhatsApp Cloud API.
        
        TODO: Implement actual API call with requests library.
        """
        raise NotImplementedError("Live WhatsApp client not yet implemented")

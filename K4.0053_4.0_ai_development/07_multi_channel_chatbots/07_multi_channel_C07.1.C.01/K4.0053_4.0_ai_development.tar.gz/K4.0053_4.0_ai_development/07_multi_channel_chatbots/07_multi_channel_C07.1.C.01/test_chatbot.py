#!/usr/bin/env python3
"""
Test script to demonstrate chatbot functionality.

Run this after starting the server with: uvicorn app:app --reload
"""

import requests
import json
import time
from pathlib import Path

BASE_URL = "http://localhost:8000"

def print_section(title):
    """Print a formatted section header."""
    print("\n" + "=" * 80)
    print(f"  {title}")
    print("=" * 80 + "\n")

def test_health_check():
    """Test the health endpoint."""
    print_section("1. Health Check")
    
    response = requests.get(f"{BASE_URL}/health")
    print(f"Status Code: {response.status_code}")
    print(f"Response: {json.dumps(response.json(), indent=2)}")
    
    assert response.status_code == 200
    print("✅ Health check passed!")

def test_whatsapp_verification():
    """Test WhatsApp webhook verification."""
    print_section("2. WhatsApp Webhook Verification")
    
    params = {
        "hub.mode": "subscribe",
        "hub.verify_token": "dev_verify_token_12345",
        "hub.challenge": "test_challenge_123"
    }
    
    response = requests.get(f"{BASE_URL}/webhook/whatsapp", params=params)
    print(f"Status Code: {response.status_code}")
    print(f"Response: {response.text}")
    
    assert response.status_code == 200
    assert response.text == "test_challenge_123"
    print("✅ WhatsApp verification passed!")

def test_webchat_message():
    """Test web chat endpoint."""
    print_section("3. Web Chat Message")
    
    payload = {
        "user_id": "web_test_user_001",
        "text": "Hello from web chat!"
    }
    
    response = requests.post(
        f"{BASE_URL}/webchat/message",
        json=payload
    )
    
    print(f"Status Code: {response.status_code}")
    print(f"Response: {json.dumps(response.json(), indent=2)}")
    
    assert response.status_code == 200
    data = response.json()
    assert "reply_text" in data
    assert "options" in data
    print("✅ Web chat test passed!")

def test_whatsapp_with_fixture(fixture_name):
    """Test WhatsApp webhook with a fixture file."""
    print_section(f"4. WhatsApp Webhook - {fixture_name}")
    
    fixture_path = Path(__file__).parent / "fixtures" / f"{fixture_name}.json"
    
    with open(fixture_path) as f:
        payload = json.load(f)
    
    print(f"Loading fixture: {fixture_path.name}")
    print(f"User message: \"{payload['entry'][0]['changes'][0]['value']['messages'][0]['text']['body']}\"")
    print("\nSending to webhook...")
    
    response = requests.post(
        f"{BASE_URL}/webhook/whatsapp",
        json=payload
    )
    
    print(f"\nStatus Code: {response.status_code}")
    print(f"Response: {json.dumps(response.json(), indent=2)}")
    
    assert response.status_code == 200
    print(f"✅ {fixture_name} test passed!")
    print("\n📋 Check the server console logs to see the MOCK WhatsApp reply!")

def test_session_management():
    """Test session creation and cleanup."""
    print_section("5. Session Management")
    
    # Send multiple messages to create sessions
    print("Creating sessions with multiple users...")
    
    for i in range(3):
        payload = {
            "user_id": f"session_test_user_{i}",
            "text": f"Test message {i}"
        }
        requests.post(f"{BASE_URL}/webchat/message", json=payload)
        print(f"  Created session for user {i}")
    
    time.sleep(0.5)
    
    # Check health to see active sessions
    response = requests.get(f"{BASE_URL}/health")
    data = response.json()
    print(f"\nActive sessions: {data['active_sessions']}")
    
    # Cleanup sessions
    response = requests.get(f"{BASE_URL}/sessions/cleanup")
    data = response.json()
    print(f"\nCleanup result: {json.dumps(data, indent=2)}")
    
    print("✅ Session management test passed!")

def main():
    """Run all tests."""
    print("\n" + "🤖 " * 20)
    print("  MULTI-CHANNEL CHATBOT TEST SUITE")
    print("🤖 " * 20)
    print("\n⚠️  Make sure the server is running: uvicorn app:app --reload\n")
    
    input("Press Enter to start tests...")
    
    try:
        test_health_check()
        test_whatsapp_verification()
        test_webchat_message()
        test_whatsapp_with_fixture("whatsapp_opening_hours")
        test_whatsapp_with_fixture("whatsapp_order_status")
        test_whatsapp_with_fixture("whatsapp_unknown")
        test_session_management()
        
        print("\n" + "=" * 80)
        print("  ✅ ALL TESTS PASSED!")
        print("=" * 80)
        print("\n📝 Next steps:")
        print("  1. Implement intent detection in core/intent_detector.py")
        print("  2. Implement entity extraction in core/entity_extractor.py")
        print("  3. Implement data layer for business_data.json")
        print("  4. Update business_logic.py with real responses")
        print("  5. Add unit and integration tests")
        print("\n")
        
    except requests.exceptions.ConnectionError:
        print("\n❌ ERROR: Cannot connect to server!")
        print("   Make sure the server is running:")
        print("   uvicorn app:app --reload")
        print()
    except AssertionError as e:
        print(f"\n❌ TEST FAILED: {e}")
    except Exception as e:
        print(f"\n❌ UNEXPECTED ERROR: {e}")

if __name__ == "__main__":
    main()

"""
Multi-channel chatbot FastAPI application.

Provides webhook endpoints for WhatsApp Business API and web chat.
Supports both mock and live modes for development and production.
"""

from fastapi import FastAPI, Request, Response, HTTPException
from fastapi.responses import JSONResponse, PlainTextResponse
from typing import Dict, Any

from config import settings
from utils import logger
from core import (
    IncomingMessage,
    OutgoingMessage,
    context_manager,
    process_message,
)
from core.models import WebChatRequest, WebChatResponse
from channels import parse_whatsapp_webhook, MockWhatsAppClient, LiveWhatsAppClient

# Initialize FastAPI app
app = FastAPI(
    title="Multi-Channel Chatbot",
    description="Customer support chatbot with WhatsApp and Web Chat integration",
    version="1.0.0",
)

# Initialize WhatsApp client based on mode
if settings.mode == "mock":
    whatsapp_client = MockWhatsAppClient()
else:
    whatsapp_client = LiveWhatsAppClient(
        access_token=settings.whatsapp_access_token,
        phone_number_id=settings.whatsapp_phone_number_id,
    )

logger.info(f"Application started in {settings.mode.upper()} mode")


@app.on_event("startup")
async def startup_event():
    """Log startup information."""
    logger.info("=" * 80)
    logger.info("🚀 Multi-Channel Chatbot Starting...")
    logger.info(f"Mode: {settings.mode.upper()}")
    logger.info(f"Log Format: {settings.log_format}")
    logger.info(f"Session TTL: {settings.session_ttl_minutes} minutes")
    logger.info("=" * 80)


@app.get("/health")
async def health_check():
    """
    Health check endpoint.
    
    Returns:
        Status and active session count
    """
    return {
        "status": "healthy",
        "mode": settings.mode,
        "active_sessions": context_manager.get_session_count(),
    }


@app.get("/webhook/whatsapp")
async def whatsapp_webhook_verify(request: Request):
    """
    WhatsApp webhook verification endpoint.
    
    Meta sends a GET request with these query parameters:
    - hub.mode: Should be "subscribe"
    - hub.verify_token: Must match WHATSAPP_VERIFY_TOKEN
    - hub.challenge: Random string to echo back
    
    See: https://developers.facebook.com/docs/graph-api/webhooks/getting-started
    """
    params = request.query_params
    
    mode = params.get("hub.mode")
    token = params.get("hub.verify_token")
    challenge = params.get("hub.challenge")
    
    logger.info(f"WhatsApp verification request: mode={mode}, token_match={token == settings.whatsapp_verify_token}")
    
    # Verify the request
    if mode == "subscribe" and token == settings.whatsapp_verify_token:
        logger.info("✅ WhatsApp webhook verified successfully")
        # Return the challenge to complete verification
        return PlainTextResponse(content=challenge)
    else:
        logger.warning("❌ WhatsApp webhook verification failed")
        raise HTTPException(status_code=403, detail="Verification failed")


@app.post("/webhook/whatsapp")
async def whatsapp_webhook_receive(request: Request):
    """
    WhatsApp webhook message receiver.
    
    Receives incoming messages from WhatsApp Business API,
    processes them through business logic, and sends replies.
    
    Always returns 200 OK to prevent WhatsApp from retrying.
    Errors are logged but don't affect the response status.
    """
    try:
        # Parse JSON payload
        payload: Dict[str, Any] = await request.json()
        logger.debug(f"Received WhatsApp webhook: {payload}")
        
        # Extract user ID and message text
        parsed = parse_whatsapp_webhook(payload)
        
        if not parsed:
            # Not a message event (could be status update)
            logger.debug("Webhook received but no message to process")
            return {"status": "ok"}
        
        user_id, text = parsed
        
        # Create normalized incoming message
        incoming = IncomingMessage(
            channel="whatsapp",
            user_id=user_id,
            text=text,
            raw_payload=payload,
        )
        
        # Get or create session
        session = context_manager.get_session(user_id=user_id, channel="whatsapp")
        
        # Process message through business logic
        outgoing = process_message(incoming, session)
        
        # Send reply via WhatsApp
        try:
            result = whatsapp_client.send_message(
                to=user_id,
                text=outgoing.text,
                buttons=outgoing.options,
            )
            logger.info(f"Reply sent successfully: {result}")
        except Exception as send_error:
            logger.error(f"Failed to send WhatsApp reply: {send_error}", exc_info=True)
            # Don't raise - we still return 200 to WhatsApp
        
        return {"status": "ok"}
        
    except Exception as e:
        # Log error but return 200 to prevent WhatsApp retries
        logger.error(f"Error processing WhatsApp webhook: {e}", exc_info=True)
        return {"status": "error", "message": "Internal error (logged)"}


@app.post("/webchat/message", response_model=WebChatResponse)
async def webchat_message(request: WebChatRequest):
    """
    Web chat message endpoint.
    
    Accepts messages from web chat interface and returns responses.
    This is the second channel implementation.
    
    Example request:
    POST /webchat/message
    {
        "user_id": "web_session_abc123",
        "text": "Hello"
    }
    """
    try:
        logger.info(f"Web chat message from {request.user_id}: {request.text}")
        
        # Create normalized incoming message
        incoming = IncomingMessage(
            channel="webchat",
            user_id=request.user_id,
            text=request.text,
        )
        
        # Get or create session
        session = context_manager.get_session(
            user_id=request.user_id,
            channel="webchat"
        )
        
        # Process message
        outgoing = process_message(incoming, session)
        
        # Return response
        return WebChatResponse(
            reply_text=outgoing.text,
            options=outgoing.options,
        )
        
    except Exception as e:
        logger.error(f"Error processing webchat message: {e}", exc_info=True)
        raise HTTPException(
            status_code=500,
            detail="Failed to process message"
        )


@app.get("/sessions/cleanup")
async def cleanup_sessions():
    """
    Manually trigger session cleanup.
    
    Removes expired sessions. In production, this would run
    on a schedule (e.g., every 5 minutes via background task).
    """
    removed = context_manager.cleanup_expired_sessions()
    return {
        "status": "ok",
        "sessions_removed": removed,
        "active_sessions": context_manager.get_session_count(),
    }


# Error handlers
@app.exception_handler(404)
async def not_found_handler(request: Request, exc: HTTPException):
    """Custom 404 handler."""
    return JSONResponse(
        status_code=404,
        content={"error": "Endpoint not found", "path": str(request.url)}
    )


@app.exception_handler(500)
async def internal_error_handler(request: Request, exc: Exception):
    """Custom 500 handler."""
    logger.error(f"Internal server error: {exc}", exc_info=True)
    return JSONResponse(
        status_code=500,
        content={"error": "Internal server error"}
    )


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)

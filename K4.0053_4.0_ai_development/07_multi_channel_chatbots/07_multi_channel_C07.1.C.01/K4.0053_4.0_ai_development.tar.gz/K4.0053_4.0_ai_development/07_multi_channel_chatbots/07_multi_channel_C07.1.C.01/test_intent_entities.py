#!/usr/bin/env python3
"""
Test script for intent detection and entity extraction.

Tests the "brain" of the chatbot - understanding user intent
and extracting specific details from messages.
"""

import sys
from pathlib import Path

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent))

from core.intent_detector import detect_intent
from core.entity_extractor import extract_entities


def print_section(title):
    """Print formatted section header."""
    print("\n" + "=" * 80)
    print(f"  {title}")
    print("=" * 80 + "\n")


def test_intent(text: str, expected_intent: str = None):
    """
    Test intent detection for a message.
    
    Args:
        text: User message
        expected_intent: Expected intent name (optional, for validation)
    """
    intent = detect_intent(text)
    
    status = "✅" if expected_intent is None or intent.name == expected_intent else "❌"
    
    print(f"{status} '{text}'")
    print(f"   → Intent: {intent.name} (confidence: {intent.confidence:.2f})")
    
    if expected_intent and intent.name != expected_intent:
        print(f"   ⚠️  Expected: {expected_intent}")
    
    return intent


def test_entities(text: str, intent_name: str = None):
    """
    Test entity extraction for a message.
    
    Args:
        text: User message
        intent_name: Intent to pass to extractor
    """
    entities = extract_entities(text, intent_name)
    
    print(f"📌 '{text}'")
    print(f"   Intent context: {intent_name}")
    
    if entities:
        for entity in entities:
            print(f"   → {entity.type}: '{entity.value}' (confidence: {entity.confidence:.2f})")
    else:
        print(f"   → No entities found")
    
    return entities


def test_opening_hours_intent():
    """Test opening hours intent detection."""
    print_section("1. Opening Hours Intent")
    
    test_cases = [
        ("When are you open?", "opening_hours"),
        ("What are your opening hours?", "opening_hours"),
        ("Are you open today?", "opening_hours"),
        ("What time do you close?", "opening_hours"),
        ("Opening hours for Monday?", "opening_hours"),
        ("When do you open tomorrow?", "opening_hours"),
    ]
    
    for text, expected in test_cases:
        test_intent(text, expected)
    
    print("\n✅ Opening hours intent tests completed")


def test_product_info_intent():
    """Test product info intent detection."""
    print_section("2. Product Info Intent")
    
    test_cases = [
        ("How much is a cappuccino?", "product_info"),
        ("What's the price of espresso?", "product_info"),
        ("Do you have coffee?", "product_info"),
        ("Show me your menu", "product_info"),
        ("What products do you sell?", "product_info"),
        ("Tell me about your pastries", "product_info"),
    ]
    
    for text, expected in test_cases:
        test_intent(text, expected)
    
    print("\n✅ Product info intent tests completed")


def test_order_status_intent():
    """Test order status intent detection."""
    print_section("3. Order Status Intent")
    
    test_cases = [
        ("What's the status of my order?", "order_status"),
        ("Track order A123", "order_status"),
        ("Where is my order?", "order_status"),
        ("Check order status", "order_status"),
        ("When will my order arrive?", "order_status"),
        ("Order tracking", "order_status"),
    ]
    
    for text, expected in test_cases:
        test_intent(text, expected)
    
    print("\n✅ Order status intent tests completed")


def test_unknown_intent():
    """Test unknown/ambiguous intents."""
    print_section("4. Unknown/Ambiguous Intents")
    
    test_cases = [
        "Hello",
        "Hi there!",
        "Thanks",
        "Goodbye",
        "Help me",
        "What?",
    ]
    
    for text in test_cases:
        intent = test_intent(text)
        if intent.name != "unknown":
            print(f"   ⚠️  Unexpected intent detection for greeting/unclear message")
    
    print("\n✅ Unknown intent tests completed")


def test_entity_extraction_orders():
    """Test order ID entity extraction."""
    print_section("5. Order ID Entity Extraction")
    
    test_cases = [
        ("Check order A123", "order_status"),
        ("My order is B456", "order_status"),
        ("Track order number C7890", "order_status"),
        ("a123", "order_status"),  # Lowercase
        ("What about A123 and B456?", "order_status"),  # Multiple
    ]
    
    for text, intent in test_cases:
        test_entities(text, intent)
    
    print("\n✅ Order ID extraction tests completed")


def test_entity_extraction_products():
    """Test product name entity extraction."""
    print_section("6. Product Name Entity Extraction")
    
    test_cases = [
        ("How much is a cappuccino?", "product_info"),
        ("Price of espresso", "product_info"),
        ("I want a latte", "product_info"),
        ("Do you have croissant?", "product_info"),
        ("Tell me about cap", "product_info"),  # Alias
    ]
    
    for text, intent in test_cases:
        test_entities(text, intent)
    
    print("\n✅ Product name extraction tests completed")


def test_entity_extraction_days():
    """Test day entity extraction."""
    print_section("7. Day Entity Extraction")
    
    test_cases = [
        ("Are you open today?", "opening_hours"),
        ("Hours for tomorrow", "opening_hours"),
        ("Open on Monday?", "opening_hours"),
        ("What about saturday", "opening_hours"),
        ("Mon and Tue hours", "opening_hours"),  # Abbreviations
    ]
    
    for text, intent in test_cases:
        test_entities(text, intent)
    
    print("\n✅ Day extraction tests completed")


def test_entity_extraction_categories():
    """Test product category extraction."""
    print_section("8. Product Category Extraction")
    
    test_cases = [
        ("Show me coffee options", "product_info"),
        ("Do you have tea?", "product_info"),
        ("What pastries do you sell?", "product_info"),
    ]
    
    for text, intent in test_cases:
        test_entities(text, intent)
    
    print("\n✅ Category extraction tests completed")


def test_combined_examples():
    """Test realistic combined examples."""
    print_section("9. Realistic Combined Examples")
    
    print("🔍 Example 1: Order status with ID")
    text = "What's the status of order A123?"
    intent = detect_intent(text)
    entities = extract_entities(text, intent.name)
    print(f"Message: '{text}'")
    print(f"Intent: {intent.name} ({intent.confidence:.2f})")
    for e in entities:
        print(f"  - {e.type}: {e.value}")
    
    print("\n🔍 Example 2: Product price query")
    text = "How much is a cappuccino?"
    intent = detect_intent(text)
    entities = extract_entities(text, intent.name)
    print(f"Message: '{text}'")
    print(f"Intent: {intent.name} ({intent.confidence:.2f})")
    for e in entities:
        print(f"  - {e.type}: {e.value}")
    
    print("\n🔍 Example 3: Opening hours for specific day")
    text = "Are you open on Saturday?"
    intent = detect_intent(text)
    entities = extract_entities(text, intent.name)
    print(f"Message: '{text}'")
    print(f"Intent: {intent.name} ({intent.confidence:.2f})")
    for e in entities:
        print(f"  - {e.type}: {e.value}")
    
    print("\n✅ Combined examples completed")


def main():
    """Run all intent and entity tests."""
    print("\n" + "🧠 " * 20)
    print("  INTENT & ENTITY DETECTION TEST SUITE")
    print("🧠 " * 20)
    
    try:
        test_opening_hours_intent()
        test_product_info_intent()
        test_order_status_intent()
        test_unknown_intent()
        test_entity_extraction_orders()
        test_entity_extraction_products()
        test_entity_extraction_days()
        test_entity_extraction_categories()
        test_combined_examples()
        
        print("\n" + "=" * 80)
        print("  ✅ ALL INTENT & ENTITY TESTS PASSED!")
        print("=" * 80)
        print("\n📝 The chatbot brain is working!")
        print("   Next: Connect to business logic and data layer\n")
        
    except Exception as e:
        print(f"\n❌ TEST FAILED: {e}")
        import traceback
        traceback.print_exc()
        return 1
    
    return 0


if __name__ == "__main__":
    sys.exit(main())
